/*CMPT201: Lab 1
June Bonogofski - January 16th, 2026
hello.c: a simple program that takes no input and prints "Hello World"*/

#include <stdio.h>  //need to include for printf()

int main() {        //main function
    printf("Hello World\n");    //does the printing

    return 0;       //returns an int as mian expects
}